﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.Extensions.Logging;
using Umbraco.Cms.Core.Models;
using Umbraco.Cms.Core.Models.PublishedContent;
using Umbraco.Cms.Core.Web;
using Umbraco.Cms.Web.Common.Controllers;
using Umbraco.Extensions;
using Vertica.Umbraco.Headless.Core.Controllers;
using Vertica.Umbraco.Headless.Core.Models;
using Vertica.Umbraco.Headless.Core.Rendering;
using Vertica.Umbraco.Headless.Core.Rendering.Output;

namespace Vertica.Umbraco.Headless.Test.Demo4
{
	public class CustomHeadlessRenderController : HeadlessRenderController
	{
		public CustomHeadlessRenderController(
			IContentElementBuilder contentElementBuilder,
			IOutputRenderer outputRenderer, 
			IPageDataBuilder pageDataBuilder,
			ILogger<RenderController> logger,
			ICompositeViewEngine compositeViewEngine,
			IUmbracoContextAccessor umbracoContextAccessor
		) : base(contentElementBuilder, outputRenderer, pageDataBuilder, logger, compositeViewEngine, umbracoContextAccessor)
		{
		}

		protected override IActionResult IndexFor(IPageData pageData, IPublishedContent content)
		{
			var isHeadlessRequest = "application/json".Equals(Request.ContentType, StringComparison.OrdinalIgnoreCase) 
			                     || Request.Query["xhr"] == "1";

			if (isHeadlessRequest)
			{
				return base.IndexFor(pageData, content);
			}

			var primaryNavigation = UmbracoContext.Content
				.GetAtRoot()
				.First()
				.Children
				.Select(c => new NameAndUrl(c.Name, c.Url()))
				.ToArray();

			return CurrentTemplate(
				new CustomContentModel(
					OutputRenderer.Serialize(pageData),
					OutputRenderer.Serialize(primaryNavigation),
					content
				)
			);
		}
	}

	public class CustomContentModel : ContentModel
	{
		public CustomContentModel(string defaultContent, string primaryNavigation, IPublishedContent content) 
			: base(content)
		{
			DefaultContent = defaultContent;
			PrimaryNavigation = primaryNavigation;
		}

		public string DefaultContent { get; }

		public string PrimaryNavigation { get; }
	}
}
