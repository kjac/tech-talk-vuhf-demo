﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";

export class NavBreadcrumb extends LitElement {
  static properties = {
    navigation: {type: Object, attribute: false}
  };

  render() {
    return html`
<div>
  &#8618;<b>Breadcrumb navigation:</b>
  <nav style="display:inline;">
  ${this.navigation.breadcrumb.map((item) => html`<a href="${item.url}">[${item.name}]</a>`)}
  </nav>
</div>
`;
  }
}
customElements.define("nav-breadcrumb", NavBreadcrumb);
