﻿import { html, LitElement } from 'https://unpkg.com/lit-element@3.0.2/lit-element.js?module';

export class PropertyBlockList extends LitElement {

  static properties = {
    contentElements: { type: Object, attribute: false }
  };

  render() {
    return html`
<div>
  ${this.contentElements.map((contentElement) => {
      switch (contentElement.alias) {
      case "imageAndTextBlock":
        return html`<block-image-and-text .contentElement=${contentElement}></block-image-and-text>`;
      case "richTextBlock":
        return html`<block-rich-text .contentElement=${contentElement}></block-rich-text>`;
      default:
        console.warn("Missing block for content element alias", contentElement.alias);
        break;
      }
    })}
</div>
`;
  }
}
customElements.define("property-block-list", PropertyBlockList);

