﻿import { html, LitElement } from 'https://unpkg.com/lit-element@3.0.2/lit-element.js?module';

export class PropertyTextArea extends LitElement {

  static properties = {
    content: { type: Object, attribute: false }
  };

  render() {
    return html`
<div>
  ${this.content.paragraphs.map((paragraph) => html`<p>${paragraph.text}</p>`)}
</div>
`;
  }
}
customElements.define("property-text-area", PropertyTextArea);