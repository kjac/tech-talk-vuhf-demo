﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";

export class NavPrimary extends LitElement {

  connectedCallback() {
    super.connectedCallback();
    this.items = window.app.primaryNavigation;
  }

  render() {
    return html`
<div style="margin-bottom:10px;">
<b>Primary navigation:</b>
<nav style="display:inline;">
<a href="/">[Home]</a>
${this.items.map((item) => html`<a href="${item.url}">[${item.name}]</a>`)}
<a href="https://vertica.dk">[Vertica.dk]</a>
</nav>
</div>
`;
  }
}
customElements.define("nav-primary", NavPrimary);
