﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";

export class BlockImageAndText extends LitElement {
  static properties = {
    contentElement: { type: Object, attribute: false }
  };

  render() {
    const content = this.contentElement.content;
    const settings = this.contentElement.settings.content;

    return html`
<div>
<p style="background-color:#${settings.backgroundColor}; display:inline-block;">
<img src="${content.image.url}" style="max-height:150px;"/>
<property-text-area .content=${content.text}></property-text-area>
</p>
</div>
`;
  }
}
customElements.define("block-image-and-text", BlockImageAndText);
