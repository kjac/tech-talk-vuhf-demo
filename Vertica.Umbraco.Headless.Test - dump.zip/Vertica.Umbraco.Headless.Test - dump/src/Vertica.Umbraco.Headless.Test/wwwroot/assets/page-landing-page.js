﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";

export class PageLandingPage extends LitElement {
  static properties = {
    pageData: { type: Object }
  };

  render() {
    const content = this.pageData.content;

    return html`
<h2>${content.title}</h2>

<property-text-area .content=${content.intro}></property-text-area>

<property-block-list .contentElements=${content.contentBlocks}></property-block-list>

<hr/>
<i>This is the landing page component</i>
`;
  }
}
customElements.define("page-landing-page", PageLandingPage);
