﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";

export class PageUnknown extends LitElement {
  static properties = {
    pageData: { type: Object }
  };

  render() {
    const alias = this.pageData.alias;

    return html`
<h2>Unknown content type</h2>
<p>No page template defined for content type with alias: ${alias}</p>

<hr/>
<i>This is the unknown page component</i>
`;
  }
}
customElements.define("page-unknown", PageUnknown);
