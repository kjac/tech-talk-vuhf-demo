﻿import { html, LitElement } from 'https://unpkg.com/lit-element@3.0.2/lit-element.js?module';

export class AppRouter extends LitElement {

  static properties = {
    route: {type: Object}
  };

  connectedCallback() {
    super.connectedCallback();
    document.addEventListener("click", this._linkRouter);
    this._load(window.app.defaultContent);
  }


  _load = (data) => {
    switch (data.alias) {
    case "home":
      this.route = html`<page-home .pageData=${data}></page-home>`;
      break;
    case "article":
      this.route = html`<page-article .pageData=${data}></page-article>`;
      break;
    case "landingPage":
      this.route = html`<page-landing-page .pageData=${data}></page-landing-page>`;
      break;
    default:
      this.route = html`<page-unknown .pageData=${data}></page-unknown>`;
      break;
    }
  }

  _fetchRoute = () => {
    fetch(location.pathname, { headers: { "Content-Type": "application/json" } })
      .then(response => response.json())
      .then(data => this._load(data));
  }

  _linkRouter = (e) => {
    var link = e.path[0];
    if (link.tagName !== "A" || link.getAttribute("target") === "_blank" || link.hasAttribute("router-ignore")) {
      return;
    }

    const href = link.getAttribute("href");
    if (href.startsWith("http")) {
      return;
    }

    if (href !== location.pathname) {
      history.pushState(null, "", href);
      this._fetchRoute();
    }
    e.preventDefault();
  }

  render() {
    return html`<div>${this.route}</div>`;
  }
}
customElements.define("app-router", AppRouter);

