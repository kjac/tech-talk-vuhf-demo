﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";
import { unsafeHTML } from "https://unpkg.com/lit-html@2.0.2/directives/unsafe-html.js?module";

export class BlockRichText extends LitElement {
  static properties = {
    contentElement: { type: Object, attribute: false }
  };

  render() {
    const content = this.contentElement.content;

    return html`<div>${unsafeHTML(content.text)}</div>`;
  }
}
customElements.define("block-rich-text", BlockRichText);
