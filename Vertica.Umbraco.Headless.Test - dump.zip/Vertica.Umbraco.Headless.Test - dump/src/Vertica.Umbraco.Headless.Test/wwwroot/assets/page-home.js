﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";

export class PageHome extends LitElement {
  static properties = {
    pageData: { type: Object }
  };

  render() {
    const content = this.pageData.content;

    return html`
<h2>${content.title}</h2>
<p>${content.intro}</p>

<h3>Featured articles</h3>
<ul>
  ${content.featuredArticles.map((article) => html`<li><img src="${article.imageUrl}" style="max-height:100px;"/><a href="${article.url}">${article.title}</a></li>`)}
</ul>

<hr/>
<i>This is the home page component</i>
`;
  }
}
customElements.define("page-home", PageHome);
