﻿window.onload = function () {
  var counterElement = document.createElement("div");
  counterElement.innerText = "0";
  counterElement.style.backgroundColor = "grey";
  counterElement.style.color = "white";
  counterElement.style.position = "absolute";
  counterElement.style.top = "6px";
  counterElement.style.left = "6px";
  counterElement.style.padding = "6px";
  counterElement.style.borderRadius = "4px";
  counterElement.style.minWidth = "26px";
  counterElement.style.textAlign = "center";

  document.body.appendChild(counterElement);

  document.body.style.marginLeft = "50px";
  
  var counter = 0;
  setInterval(() => {
    counter++;
    counterElement.innerText = counter;
  }, 1000);
}