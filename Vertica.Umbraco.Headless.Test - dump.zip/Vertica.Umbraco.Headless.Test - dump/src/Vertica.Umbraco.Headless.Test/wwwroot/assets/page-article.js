﻿import { html, LitElement } from "https://unpkg.com/lit-element@3.0.2/lit-element.js?module";
import { unsafeHTML } from "https://unpkg.com/lit-html@2.0.2/directives/unsafe-html.js?module";

export class PageArticle extends LitElement {
  static properties = {
    pageData: { type: Object, attribute: false }
  };

  render() {
    const content = this.pageData.content;
    const navigation = this.pageData.navigation;

    return html`
<nav-secondary .navigation=${navigation}></nav-secondary>
<nav-breadcrumb .navigation=${navigation}></nav-breadcrumb>

<h2>${content.title}</h2>
<img src="${content.image.url}" style="max-height:200px;"/>
<div>${unsafeHTML(content.body)}</div>

<hr/>
<i>This is the article page component</i>
`;
  }
}
customElements.define("page-article", PageArticle);
