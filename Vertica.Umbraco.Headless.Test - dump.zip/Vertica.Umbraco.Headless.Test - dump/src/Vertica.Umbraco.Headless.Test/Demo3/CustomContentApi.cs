﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Umbraco.Cms.Web.Common;
using Umbraco.Cms.Web.Common.Controllers;
using Umbraco.Extensions;
using Vertica.Umbraco.Headless.Core.Extensions;
using Vertica.Umbraco.Headless.Core.Models;
using Vertica.Umbraco.Headless.Core.Rendering;
using Vertica.Umbraco.Headless.Core.Rendering.Output;

namespace Vertica.Umbraco.Headless.Test.Demo3
{
	// example request: /umbraco/api/customcontentapi/articles?pageNumber=1
	// NOTE: a slightly simpler approach would be to use HeadlessApiController as base controller
	public class CustomContentApiController : UmbracoApiController
	{
		private readonly IContentElementBuilder _contentElementBuilder;
		private readonly IOutputRenderer _outputRenderer;
		private readonly UmbracoHelper _umbracoHelper;

		public CustomContentApiController(IContentElementBuilder contentElementBuilder, IOutputRenderer outputRenderer, UmbracoHelper umbracoHelper) 
		{
			_contentElementBuilder = contentElementBuilder;
			_outputRenderer = outputRenderer;
			_umbracoHelper = umbracoHelper;
		}

		[HttpGet]
		public IActionResult Articles(int pageNumber)
		{
			const int pageSize = 3;

			// THIS IS NOT OPTIMAL QUERYING BY ANY MEANS (but it works for demo purposes)
			var articles = _umbracoHelper
				.ContentAtRoot()
				.First()
				.DescendantsOfType("article")
				.ToArray();
			
			var contentElements = articles
				.Skip(pageNumber * pageSize)
				.Take(pageSize)
				.Select(_contentElementBuilder.ContentElementFor)
				.ToArray();

			return _outputRenderer.ActionResult(
				new ArticleResult(contentElements, articles.Length, pageNumber, pageSize)
			);
		}
	}

	public class ArticleResult 
	{
		public ArticleResult(IContentElement[] articles, int total, int pageNumber, int pageSize)
		{
			Articles = articles;
			Total = total;
			PageNumber = pageNumber;
			PageSize = pageSize;
		}

		public IContentElement[] Articles { get; set; }

		public int Total { get; }

		public int PageNumber { get; }

		public int PageSize { get; }

		public int TotalPages => (int)Math.Ceiling((decimal)Total / PageSize);
	}
}
