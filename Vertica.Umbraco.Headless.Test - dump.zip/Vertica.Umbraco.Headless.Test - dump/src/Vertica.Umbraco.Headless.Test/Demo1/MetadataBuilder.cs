﻿using System;
using Umbraco.Cms.Core.Models.PublishedContent;
using Umbraco.Cms.Core.Web;
using Vertica.Umbraco.Headless.Core.Models;
using Vertica.Umbraco.Headless.Core.Rendering;

namespace Vertica.Umbraco.Headless.Test.Demo1
{
	public class CustomMetadata : Metadata
	{
		public DateTime LastModified { get; set; }

		public bool IsPreview { get; set; }
	}

	public class CustomMetadataBuilder : MetadataBuilder
	{
		private readonly IUmbracoContextAccessor _umbracoContextAccessor;

		public CustomMetadataBuilder(IUmbracoContextAccessor umbracoContextAccessor)
		{
			_umbracoContextAccessor = umbracoContextAccessor;
		}

		public override IMetadata BuildMetadata(IPublishedContent content)
		{
			var metadata = BuildMetadata<CustomMetadata>(content);

			metadata.LastModified = content.UpdateDate;

			metadata.IsPreview = _umbracoContextAccessor.TryGetUmbracoContext(out var context) && context.InPreviewMode;

			return metadata;
		}
	}
}
