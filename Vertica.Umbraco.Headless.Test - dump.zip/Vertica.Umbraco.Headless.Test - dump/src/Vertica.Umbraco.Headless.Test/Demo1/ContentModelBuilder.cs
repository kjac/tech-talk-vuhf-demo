﻿using System.Collections.Generic;
using System.Linq;
using Umbraco.Cms.Core.Models.PublishedContent;
using Umbraco.Extensions;
using Vertica.Umbraco.Headless.Core.Rendering;

namespace Vertica.Umbraco.Headless.Test.Demo1
{
	public class HomeContentModel
	{
		public string Title { get; set; }

		public string Intro { get; set; }

		public FeaturedArticle[] FeaturedArticles { get; set; }
	}

	public class FeaturedArticle
	{
		public string Title { get; set; }

		public string Url { get; set; }

		public string ImageUrl { get; set; }
	}

	public class HomeContentModelBuilder : ContentModelBuilder<HomeContentModel>
	{
		public override string ContentTypeAlias() => "home";

		protected override HomeContentModel BuildModel(IPublishedElement content, IContentElementBuilder contentElementBuilder) 
			=> new HomeContentModel
			{
				Title = content.Value<string>("title"),
				Intro = content.Value<string>("intro"),
				FeaturedArticles = content
					.Value<IEnumerable<IPublishedContent>>("featuredArticles")
					.Select(c => new FeaturedArticle
					{
						Title = c.Value<string>("title"),
						Url = c.Url(),
						ImageUrl = c.Value<IPublishedContent>("image").Url()
					})
					.ToArray(),
			};
	}
}