﻿using System;
using System.Collections.Generic;
using System.Linq;
using Umbraco.Cms.Core.Models.PublishedContent;
using Umbraco.Extensions;
using Vertica.Umbraco.Headless.Core.Models;
using Vertica.Umbraco.Headless.Core.Rendering;

namespace Vertica.Umbraco.Headless.Test.Demo1
{
	public class CustomNavigation : Navigation
	{
		public IEnumerable<NameAndUrl> Secondary { get; set; }
	}

	public class CustomNavigationBuilder : NavigationBuilder
	{
		public override INavigation BuildNavigation(IPublishedContent content)
		{
			var navigation = BuildNavigation<CustomNavigation>(content);

			const int secondaryLevel = 2;
			var secondaryLevelContent = content.AncestorOrSelf(secondaryLevel);

			navigation.Secondary = secondaryLevelContent?.Level == secondaryLevel
					? secondaryLevelContent
						.Children
						.Select(c => new NameAndUrl(c.Name, c.Url()))
						.ToArray()
					: Array.Empty<NameAndUrl>();

			return navigation;
		}
	}
}
