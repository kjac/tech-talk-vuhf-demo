﻿using System;
using System.Linq;
using Umbraco.Cms.Core;
using Umbraco.Cms.Core.Models.PublishedContent;
using Vertica.Umbraco.Headless.Core.Rendering;

namespace Vertica.Umbraco.Headless.Test.Demo2
{
	public class CustomTextArea
	{
		public CustomTextAreaParagraph[] Paragraphs { get; set; }

		public bool MultiLine => Paragraphs.Length > 1;

		public int Length => Paragraphs.Sum(p => p.Length);
	}

	public class CustomTextAreaParagraph
	{
		public string Text { get; set; }

		public int Length => Text.Length;
	}

	public class CustomTextAreaPropertyRenderer : IPropertyRenderer
	{
		public string PropertyEditorAlias => Constants.PropertyEditors.Aliases.TextArea;

		public Type TypeFor(IPublishedPropertyType propertyType) => typeof(CustomTextArea);

		public object ValueFor(object umbracoValue, IPublishedProperty property, IContentElementBuilder contentElementBuilder)
		{
			if (umbracoValue is string value)
			{
				return new CustomTextArea
				{
					Paragraphs = value
						.Split('\n', StringSplitOptions.RemoveEmptyEntries)
						.Select(text => new CustomTextAreaParagraph
						{
							Text = text
						})
						.ToArray()
				};
			}

			return null;
		}
	}
}
