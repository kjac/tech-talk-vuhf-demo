﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using Vertica.Umbraco.Headless.Core.Rendering.Output;

namespace Vertica.Umbraco.Headless.Test.Demo2
{
	public class CustomOutputRenderer : IOutputRenderer
	{
		public string Serialize(object value)
		{
			// NOTE: quick and dirty workaround for XML serializing interface properties - do not use for production

			var json = JsonConvert.SerializeObject(new { result = value }, new JsonSerializerSettings
			{
				ContractResolver = new CamelCasePropertyNamesContractResolver(),
				Converters = { new StringEnumConverter() }
			});

			var xDocument = JsonConvert.DeserializeXNode(json);
			return xDocument?.ToString();
		}

		public IActionResult ActionResult(object value) => new ContentResult
		{
			Content = Serialize(value),
			ContentType = "text/xml"
		};
	}
}
